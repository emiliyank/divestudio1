<?php

return [
	'btn_add_page' => 'Добави нова страница',
	'list_page_title' => 'Страница',
	'list_page_created_by' => 'От',
	'list_page_created_at' => 'Дата на създаване',
    'view_page_link' => 'Виж страницата',
    'edit_page_link' => 'Промени страницата',
    'delete_page_link' => 'Изтрий страницата',

	'topic' => 'Заглавие',
	'add_static_page_title' => 'Добави статична страница',

	'add_static_page_title' => 'Добави статична страница',
	'add_static_page_subtitle' => 'Добавяне на статична страница',

	'edit_static_page_title' => 'Промени статична страница',
	'edit_static_page_subtitle' => 'Промяна на статична страница',
];
