<?php

return [
	'btn_add_page' => 'Add New Page',
	'list_page_title' => 'Page',
	'list_page_created_by' => 'Created By',
	'list_page_created_at' => 'Date Created',
    'view_page_link' => 'View Page',
    'edit_page_link' => 'Edit Page',
    'delete_page_link' => 'Delete Page',

	'topic' => 'Title',
	'add_static_page_title' => 'Add Static Page',

	'add_static_page_title' => 'Add Static Page',
	'add_static_page_subtitle' => 'Add Static Page',

	'edit_static_page_title' => 'Edit Static Page',
	'edit_static_page_subtitle' => 'Edit Static Page',
];
