<?php

return [
    'contacts' => 'Contacts',
    'text1' => 'Regarding questions about how the platform works, please look at the section',
    'text2' => 'The fields marked with',
    'text3' => 'must be filled',
    'theme' => 'Theme',
    'feedback' => 'Message',
    'success'=> 'Your message was sent successfully',
];

