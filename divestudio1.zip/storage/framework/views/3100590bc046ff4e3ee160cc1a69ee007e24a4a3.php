<?php $__env->startSection('content'); ?>

<div class="header small">
	<div class="overlay">
    	<h2><?php echo e(trans('articles.articles_list_title')); ?></h2>
    </div>
</div>

<!--Header END-->

<div class="content"><!--Content Starts-->

<section>
	<div class="container">
    <div>
        <div class="article-filter center">
        	<p><a href="#">Всички статии</a> 
                <?php foreach($cl_article_types as $cm_article_type): ?>
                    <a href="#"><?php echo e($cm_article_type->getTranslation(\Session::get('language'))->article_type); ?></a>
                <?php endforeach; ?>
            </p>
		</div>
        
    	<div class="boxes boxes-articles">
        
        <?php foreach($cm_articles as $cm_article): ?>
        	<div class="box article-data">
            	<a href=<?php echo url("/single-article/$cm_article->id"); ?>>
                	<div class="image-wrap">
                    	<img src=<?php echo asset("images/upload/thumbnails/$cm_article->picture_thumb"); ?> alt="Article thumb image">
                    </div>
                    <div class="rate-form">
                    <fieldset class="rating">
                        <input type="radio" id="1star5" name="rating1" value="5" checked><label for="1star5" title="Отлично">Отлично</label>
                        <input type="radio" id="1star4" name="rating1" value="4"><label for="1star4" title="Много добро">Много добро</label>
                        <input type="radio" id="1star3" name="rating1" value="3"><label for="1star3" title="Добро">Добро</label>
                        <input type="radio" id="1star2" name="rating1" value="2"><label for="1star2" title="Средно">Средно</label>
                        <input type="radio" id="1star1" name="rating1" value="1"><label for="1star1" title="Слабо">Слабо</label>
                    </fieldset>
                    </div>
                    <h2>
                        <?php if($cm_article->hasTranslation(\Session::get('language'))): ?>
                        <?php echo e($cm_article->getTranslation(\Session::get('language'))->topic); ?>

                        <?php else: ?>
                        <?php echo e(trans('common.no_translation')); ?>

                        <?php endif; ?>
                    </h2>
                    <p class="date"><?php echo e($cm_article->date_approved); ?></p>
                    <p class="author"><?php echo e(trans('common.published_by')); ?> <strong><?php echo e($cm_article->createdBy['org_name']); ?></strong></p>
                    <p class="status"> <?php echo e(trans('articles.status')); ?> 
                            <?php if($cm_article->status === \Config::get('constants.ARTICLE_PRIVATE')): ?>
                                <span class="status-private">
                                <?php echo e(trans('articles.private_article')); ?>

                            <?php elseif($cm_article->status === \Config::get('constants.ARTICLE_PUBLIC')): ?>
                                <span class="status-public">
                                <?php echo e(trans('articles.public_article')); ?>

                            <?php else: ?>
                                <span>
                                <?php echo e(trans('articles.waiting_approval_status')); ?>

                            <?php endif; ?>
                        </span>
                    </p>
                    <span class="tags">
                        <?php echo e($cm_article->clArticleType->getTranslation(\Session::get('language'))->article_type); ?>

                    </span>
                    <p>
                        <?php if($cm_article->hasTranslation(\Session::get('language'))): ?>
                        <div>
                            <?php echo e(substr($cm_article->getTranslation(\Session::get('language'))->content, 0, 100)); ?> [...]
                        </div>
                        <?php else: ?>
                            <?php echo e(trans('common.no_translation')); ?>

                        <?php endif; ?>
                    </p>
                </a>
            </div>
        <?php endforeach; ?>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>