<?php $__env->startSection('content'); ?>
<!--Header-->

<div class="header small">
    <div class="overlay">
        <h2><?php echo e(trans('users.details_title')); ?></h2>
    </div>
</div>

<!--Header END-->

<div class="content"><!--Content Starts-->

    <section class="profile">
        <div class="container">
            <div class="boxes layout-left">
                <div class="box">

                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <?php foreach($errors->all() as $error): ?>
                        <p><?php echo e($error); ?></p>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                    <!-- Edit User Details Form -->
                    <form action="<?php echo e(url('user-details')); ?>" method="POST" class="form-horizontal">
                        <fieldset>
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>"/>

                            <h4><?php echo e(trans('users.details_subtitle')); ?></h4>
                            <p><?php echo e(trans('users.services_label')); ?><br>
                                <em><?php echo e(trans('users.services_help_text')); ?></em></p>
                                <hr>
                                <?php $i = 0; ?>

                                <?php foreach($cl_services as $service): ?>
                                <?php
                                $i++;
                                if( ! empty($user_services[$service->id]))
                                {
                                    $selected = 'checked';
                                    $display_budget = '';
                                    $min_budget = $user_services[$service->id];
                                }else{
                                    $selected = '';
                                    $display_budget = 'display: none;';
                                    $min_budget = '';
                                }
                                ?>
                                <div class="checkbox">
                                    <input type="checkbox" name="services[<?php echo e($service->id); ?>]" id="services[<?php echo e($service->id); ?>]" value="<?php echo e($service->id); ?>"  data-related-item="supply-budget<?php echo e($service->id); ?>" <?php echo e($selected); ?>>
                                    <label for="services[<?php echo e($service->id); ?>]"><?php echo e($service->getTranslation(\Session::get('language'))->service); ?></label>
                                </div>
                                <div style="display: none;">
                                    <label for="supply-budget<?php echo e($service->id); ?>"><?php echo e(trans('services.minimal_budget')); ?></label>
                                    <input type="number" min="0" name="min_budget[<?php echo e($service->id); ?>]" id="supply-budget<?php echo e($service->id); ?>" class="budget" placeholder="<?php echo e(trans('users.min_budget_placeholder')); ?>" value="<?php echo e($min_budget); ?>">
                                </div>
                                <?php endforeach; ?>

                                <p><?php echo e(trans('users.regions_label')); ?></p>
                                <hr>
                                <p style="font-size: 26px;"><a href="javascript:void(0)" onclick="$('.checkboxes-group :checkbox').prop('checked', true); $(this).blur()"><i class="fa fa-check-square"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
                                    <a href="javascript:void(0)" onclick="$('.checkboxes-group :checkbox').prop('checked', false); $(this).blur()"><i class="fa fa-square"></i></a></p>
                                    <div class="checkboxes-group">
                                     <?php foreach($cl_regions as $region): ?>
                                     <?php
                                     $selected = '';
                                     if( ! empty($user_regions[$region->id]))
                                     {
                                        $selected = 'checked';
                                    }
                                    ?>
                                    <input type="checkbox" name="regions[<?php echo e($region->id); ?>]" id="regions[<?php echo e($region->id); ?>]" value="<?php echo e($region->id); ?>" <?php echo e($selected); ?> ><label for="regions[<?php echo e($region->id); ?>]"><?php echo e($region->getTranslation(\Session::get('language'))->region); ?></label><br>
                                    <?php endforeach; ?>
                                </div>

                                <p><?php echo e(trans('users.language_label')); ?></p>
                                <hr>

                                <?php $i = 0; ?>
                                <?php foreach($cl_languages as $language): ?>
                                <?php
                                $i++;
                                $selected = '';
                                if( ! empty($user_languages[$language->language]))
                                {
                                    $selected = 'checked';
                                }
                                ?>
                                <div class="checkbox">
                                    <input type="checkbox" name="languages[<?php echo e($i); ?>]" id="languages_<?php echo e($i); ?>" value="<?php echo e($language->language); ?>" <?php echo e($selected); ?>>
                                    <label for="languages_<?php echo e($i); ?>"><?php echo e($language->language); ?></label>
                                </div>
                                <?php endforeach; ?>

                                <script type="text/javascript">
                                $('#languages_1').change(function() {
                                    $('#supply-english-description-wrapper').slideToggle(200, function() {equalheight('.boxes .box');});
                                });
                                </script>

                                <p><?php echo e(trans('users.description_label')); ?></p>

                                <label for="description_bg"><span class="red">*</span>:</label>
                                <textarea name="description_bg" id="description_bg" placeholder="<?php echo e(trans('users.description_bg')); ?>" onFocus="focusLink(true)" onBlur="focusLink(false)"><?php if($user->hasTranslation(\Config::get('constants.LANGUAGE_BG'))): ?><?php echo e($user->getTranslation(\Config::get('constants.LANGUAGE_BG'))->description); ?><?php endif; ?></textarea>

                                <div id="supply-english-description-wrapper">
                                    <label for="description_en"><?php echo e(trans('users.description_en')); ?><span class="red">*</span>:</label>
                                    <textarea name="description_en" id="description_en" placeholder="<?php echo e(trans('users.description_en')); ?>"><?php if($user->hasTranslation(\Config::get('constants.LANGUAGE_EN'))): ?><?php echo e($user->getTranslation(\Config::get('constants.LANGUAGE_EN'))->description); ?><?php endif; ?> </textarea>
                                </div>

                                <input type="submit" value="<?php echo e(trans('common.btn_save')); ?>">
                                
                            </fieldset>
                        </form>
                    </div>

                    <?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>