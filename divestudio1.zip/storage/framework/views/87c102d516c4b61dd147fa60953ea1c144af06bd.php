<?php $__env->startSection('content'); ?>
    <?php if(session('rating_ad_privillege')): ?>
        <h3 class="alert alert-danger">
            <?php echo e(session('rating_ad_privillege')); ?>

        </h3>
    <?php endif; ?>

    <?php if(session('rating_ad_expired')): ?>
        <h3 class="alert alert-danger">
            <?php echo e(session('rating_ad_expired')); ?>

        </h3>
    <?php endif; ?>
    <div class="container">
        <div class="form-group form-horizontal">
            <label class="col-sm-3 control-label">Title</label>
            <div class="col-sm-6">
                <div class="form-control"><?php echo e($ad->title); ?></div>
            </div>
        </div><br/><br/>
        <div class="form-group form-horizontal">
            <label class="col-sm-3 control-label">Service</label>
            <div class="col-sm-6">
                <div class="form-control"><?php echo e($service->service_en); ?></div>
            </div>
        </div><br/><br/>
        <div class="form-group form-horizontal">
            <label class="col-sm-3 control-label">Region</label>
            <div class="col-sm-6">
                <div class="form-control"><?php echo e($region->region_en); ?></div>
            </div>
        </div><br/><br/>
        <div class="form-group form-horizontal">
            <label class="col-sm-3 control-label">Content</label>
            <div class="col-sm-6">
                <div class="form-control"><?php echo e($ad->content); ?></div>
            </div>
        </div><br/><br/>
        <div class="form-group form-horizontal">
            <label class="col-sm-3 control-label">Deadline</label>
            <div class="col-sm-6">
                <div class="form-control"><?php echo e($ad->deadline); ?></div>
            </div>
        </div><br/><br/>
        <div class="form-group form-horizontal">
            <label class="col-sm-3 control-label">Budget</label>
            <div class="col-sm-6">
                <div class="form-control"><?php echo e($ad->budget); ?></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>