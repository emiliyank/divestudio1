<?php $__env->startSection('content'); ?>
<!--Header-->

<div class="header small">
    <div class="overlay">
        <h2><?php echo e(trans('ads.user_ads_title')); ?></h2>
    </div>
</div>

<!--Header END-->

<div class="content"><!--Content Starts-->

<section class="profile">
    <div class="container">
        <div class="boxes layout-left">
        <div class="box">
            
            <?php foreach($ads as $cm_ad): ?>
            <?php if($cm_ad->hasTranslation(\Session::get('language'))): ?>
            <div class="user-box">
                <div class="header">
                    <h5>
                        <?php echo e($cm_ad->getTranslation(\Session::get('language'))->title); ?>

                    </h5>
                </div>
                <div class="container">
                    <p class="author"><?php echo e(trans('ads.author')); ?> <span><?php echo e($cm_ad->createdBy->name); ?></span></p>
                    <p class="tags"><?php echo e(trans('ads.service')); ?> <span><?php echo e($cm_ad->clService->getTranslation(\Session::get('language'))->service); ?></span></p>
                    <p class="date"><?php echo e(trans('ads.created_at')); ?> <span><?php echo e($cm_ad->created_at); ?></span></p>
                    <p>
                        <?php echo e($cm_ad->getTranslation(\Session::get('language'))->content); ?>

                    </p>
                    <p class="budget"><?php echo e(trans('ads.budget')); ?> <span><?php echo e($cm_ad->budget); ?></span></p>
                    <p class="region"><?php echo e(trans('ads.region')); ?>

                        <?php foreach($cm_ad->clRegions as $cl_region): ?>
                        <span>
                            <?php echo e($cl_region->getTranslation(\Session::get('language'))->region); ?>

                        </span>
                        <?php endforeach; ?>
                    </p>
                    <p class="due-date"><?php echo e(trans('ads.deadline')); ?> <span><?php echo e($cm_ad->deadline); ?></span></p>
                    <hr>
                    <p class="view-profile center"><a href="#"><?php echo e(trans('common.view_profile')); ?></a></p>
                    <p class="send-message center"><a href="javascript:void(0)" onClick="$('#conversation-reply-wrapper1').slideToggle(200, function() {equalheight('.boxes .box');});"><?php echo e(trans('common.write_msg')); ?></a></p>
                    <div id="conversation-reply-wrapper1" style="display: none;">
                        <form id="reply-form1" method="post" action="/">
                        <fieldset>
                            <textarea name="conversation-reply1" id="conversation-reply1" placeholder="Съобщение" onFocus="focusLink(true)" onBlur="focusLink(false)"></textarea>
                            <input type="submit" value="Изпрати">
                        </fieldset>
                        </form>
                    </div>
                </div>
                <div class="messages">
                    <hr>
                    <p class="center"><em><?php echo e(trans('common.no_msgs')); ?></em></p>
                </div>
            </div> 
            <?php endif; ?>
            <?php endforeach; ?>
        </div>
            

    
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>