<?php $__env->startSection('content'); ?>
<!--Header-->

<div class="header small">
    <div class="overlay">
        <h2>Вход</h2>
    </div>
</div>

<!--Header END-->
<div class="content"><!--Content Starts-->

<section>
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                    <fieldset>
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="username" type="text" class="username form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(trans('auth.placeholder_username')); ?>">

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="password form-control" name="password" placeholder="<?php echo e(trans('auth.placeholder_password')); ?>">

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <div class="checkbox float-left">
                                    <input type="checkbox" name="remember" id="remember">
                                    <label for="remember"><?php echo e(trans('auth.remember_me')); ?></label>
                                </div>
                            </div>
                        </div>
                        <div class="pass-forgot float-right">
                            <a class="btn btn-link" href="<?php echo e(url('/password/reset')); ?>"><?php echo e(trans('auth.forgotten_pass')); ?></a>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <input type="submit" value="<?php echo e(trans('auth.btn_login')); ?>">
                            </div>
                        </div>
                    </fieldset>
                    </form>

                    <div class="center">
                        <p><strong>Нямате профил в Счетоводно.com?</strong></p>
                    
                        <div class="go-register"><a href="<?php echo e(url('register')); ?>">Регистрирай се</a></div>
                    </div>

                </div>
            </div>
        </div>
        
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>