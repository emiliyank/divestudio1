<?php $__env->startSection('content'); ?>
    <h1> <?php echo e(trans('offers.add_offers_title')); ?> </h1>

    <div class="container">
        <div class="form-group form-horizontal">
            <label class="col-sm-3 control-label"><?php echo e(trans('ads.title')); ?></label>
            <div class="col-sm-6">
                <?php echo e($cm_ad->title); ?>

            </div>
        </div><br/><br/>
        <div class="form-group form-horizontal">
            <label class="col-sm-3 control-label"><?php echo e(trans('ads.service')); ?></label>
            <div class="col-sm-6">
                <?php echo e($service->getTranslation(\Session::get('language'))->service); ?>

            </div>
        </div><br/><br/>
        <div class="form-group form-horizontal">
            <label class="col-sm-3 control-label"><?php echo e(trans('ads.region')); ?></label>
            <div class="col-sm-6">
                <?php echo e($region->getTranslation(\Session::get('language'))->region); ?>

            </div>
        </div><br/><br/>
        <div class="form-group form-horizontal">
            <label class="col-sm-3 control-label"><?php echo e(trans('ads.content')); ?></label>
            <div class="col-sm-6">
               <?php echo e($cm_ad->content); ?>

            </div>
        </div><br/><br/>
        <div class="form-group form-horizontal">
            <label class="col-sm-3 control-label"><?php echo e(trans('ads.deadline')); ?></label>
            <div class="col-sm-6">
                <?php echo e($cm_ad->deadline); ?>

            </div>
        </div><br/><br/>
        <div class="form-group form-horizontal">
            <label class="col-sm-3 control-label"><?php echo e(trans('ads.budget')); ?></label>
            <div class="col-sm-6">
                <?php echo e($cm_ad->budget); ?>

            </div>
        </div>
    </div>

    <table class="table table-striped table-bordered table-striped table-hover dataTable">
        <!-- Table Headings -->
                    <thead>
                        <th><?php echo e(trans('offers.table_supplier')); ?></th>
                        <th><?php echo e(trans('offers.table_price')); ?></th>
                        <th><?php echo e(trans('offers.table_comment')); ?></th>
                        <th><?php echo e(trans('offers.table_type')); ?></th>
                        <th><?php echo e(trans('offers.table_deadline')); ?></th>
                        <th></th>
                    </thead>

                    <!-- Table Body -->
                    <tbody>
                        <?php foreach($cm_offers as $offer): ?>
                        <tr>
                            <td class="table-text">
                                <div><?php echo e($offer->createdBy['name']); ?></div>
                            </td>
                            <td class="table-text">
                                <div><?php echo e($offer->price); ?></div>
                            </td>
                            <td class="table-text">
                                <div>
                                    <?php if($offer->hasTranslation(\Session::get('language'))): ?>
                                        <?php echo e($offer->getTranslation(\Session::get('language'))->comment); ?>

                                    <?php else: ?>
                                        <?php
                                            echo link_to_route('route.offer_translate', $title = trans('common.btn_add_translation'), $parameters = array('cm_ad' => $cm_ad->id, 'cm_offer' => $offer->id), $attributes = array('class' =>"btn btn-warning", 'title' => "{{trans('offers.offer_translate')}}")); 
                                        ?>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="table-text">
                                <div>
                                    <?php if($offer->hasTranslation(\Session::get('language'))): ?>
                                        <?php echo e($offer->getTranslation(\Session::get('language'))->type); ?>

                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="table-text">
                                <div><?php echo e($offer->deadline); ?></div>
                            </td>
                            <td>
                                <?php if(! $cm_ad->date_accepted): ?>
                                <form action="<?php echo e(url('/approve_offer/'.$offer->id)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <?php
                                        echo Form::hidden('cm_ad_id', $cm_ad->id, array('class' => 'form-control'));
                                    ?>
                                    <button type="submit" class="btn btn-success" id="approve" onclick="validate_deletion($offer->id)">
                                        <?php echo e(trans('offers.btn_approve')); ?>

                                    </button>
                                </form>
                                <?php elseif($offer->is_approved): ?>
                                    <label class="label label-success"><?php echo e(trans('offers.approved')); ?> </label>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
        <?php
            echo link_to_route('route.ads_list', $title = trans('offers.btn_cancel'), $parameters = null, $attributes = array('class' =>"btn btn-default pull-right", 'title' => "{{trans('offers.btn_cancel')}}"));
        ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>