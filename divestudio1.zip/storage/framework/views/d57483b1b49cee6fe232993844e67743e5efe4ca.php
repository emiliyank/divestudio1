<?php $__env->startSection('content'); ?>
<!--Header-->

<div class="header small">
    <div class="overlay">
        <h2>Нова обява</h2>
    </div>
</div>

<!--Header END-->

<div class="content"><!--Content Starts-->

<section class="profile">
    <div class="container">
        <div class="boxes layout-left">
        <div class="box">

            <!-- New Ad Form -->
            <form action="<?php echo e(url('ad')); ?>" method="POST" class="form-horizontal">
            <fieldset>
                <?php echo e(csrf_field()); ?>


                <h4>Нова обява</h4>
                <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                    <div class="col-sm-6">
                        <input type="text" name="title" id="title" class="form-control" value="<?php echo e(old('title')); ?>" placeholder="<?php echo e(trans('ads.placeholder_title')); ?>">
                        <?php if($errors->has('title')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('title')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('service_id') ? ' has-error' : ''); ?>">
                    <div class="col-md-6">
                        <select id="service_id" class="form-control" name="service_id" placeholder="<?php echo e(trans('ads.placeholder_service')); ?>">
                            <option value=""><?php echo e(trans('ads.placeholder_service')); ?> </option>
                            <?php foreach($cl_services as $service): ?>
                                <option value="<?php echo e($service->id); ?>" <?php echo e((old('service_id') == $service->id) ? "selected":""); ?>><?php echo e($service->getTranslation(\Session::get('language'))->service); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if($errors->has('service_id')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('service_id')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="form-group<?php echo e($errors->has('content') ? ' has-error' : ''); ?>">
                    <div class="col-md-6">
                        <textarea id="content" class="form-control" name="content" placeholder="<?php echo e(trans('ads.placeholder_content')); ?>"><?php echo e(old('content')); ?></textarea>
                        <?php if($errors->has('content')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('content')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <p>Бюджет на услугата:</p>
                <hr>

                <div class="form-group<?php echo e($errors->has('budget') ? ' has-error' : ''); ?>">
                    <div class="col-sm-6">
                        <input type="number" min="0" name="budget" id="budget" class="budget" value="<?php echo e(old('budget')); ?>" placeholder="<?php echo e(trans('ads.placeholder_budget')); ?>">
                        <?php if($errors->has('budget')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('budget')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <p>Да се търси изпълнител в:</p>
                <hr>
                <p style="font-size: 26px;"><a href="javascript:void(0)" onclick="$('.checkboxes-group :checkbox').prop('checked', true); $(this).blur()"><i class="fa fa-check-square"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
                <a href="javascript:void(0)" onclick="$('.checkboxes-group :checkbox').prop('checked', false); $(this).blur()"><i class="fa fa-square"></i></a></p>
                <div class="checkboxes-group">
                     <?php foreach($cl_regions as $region): ?>
                        <?php
                            $selected = '';
                            if(old('regions') && array_key_exists($region->id, old('regions')))
                            {
                                $selected = 'checked';
                            }
                        ?>
                        <input type="checkbox" name="regions[<?php echo e($region->id); ?>]" id="regions[<?php echo e($region->id); ?>]" value="<?php echo e($region->id); ?>" <?php echo e($selected); ?> ><label for="regions[<?php echo e($region->id); ?>]"><?php echo e($region->getTranslation(\Session::get('language'))->region); ?></label><br>
                    <?php endforeach; ?>
                </div>

                <div class="form-group<?php echo e($errors->has('deadline') ? ' has-error' : ''); ?>">
                    <div class="datepicker-wrapper">
                        <script>
                            
                        </script>
                        <label for="date">Крайна дата за получаване на оферти:</label>
                        <input type="text" name="deadline" id="deadline" class="date-picker" value="<?php echo e(old('deadline')); ?>" placeholder="<?php echo e(trans('ads.placeholder_deadline')); ?>">
                        <?php if($errors->has('deadline')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('deadline')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <hr>
                <div class="checkbox">
                    <input type="checkbox" name="supply-agreement" id="supply-agreement" required value="Agreed with Ptivacy Policy" <?php echo e((old('supply-agreement') == 'Agreed with Ptivacy Policy') ? "checked":""); ?>>
                    <label for="supply-agreement">Прочел съм и съм съгласен с <a href="#" target="_blank">Общите условия</a><span class="red">*</span></label>
                </div>                

                <div class="form-group">
                    <input type="submit" value="Публикувай">
                </div>
            </fieldset>
            </form>
        </div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>