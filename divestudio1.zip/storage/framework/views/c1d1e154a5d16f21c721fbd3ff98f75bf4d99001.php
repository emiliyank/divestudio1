<?php $__env->startSection('content'); ?>
<!--Header-->

<div class="header small">
    <div class="overlay">
        <h2><?php echo e(trans('register.registration')); ?></h2>
    </div>
</div>

<!--Header END-->
<div class="content"><!--Content Starts-->
    <section>
        <div class="container">

            <h4><?php echo e(trans('register.role')); ?></h4>
            <p class="center"><?php echo e(trans('register.choice_role')); ?> <a href="#"><?php echo e(trans('register.more_for_roles')); ?></a>.)</p>
            <ul class="role-select">
        	<li><a href="javascript:void(0)" onClick="$('.supply').hide(); $('.demand').fadeIn(); $('#user_type').val('1');"><?php echo e(trans('common.btn_seeking')); ?></a></li>
                <li><a href="javascript:void(0)" onClick="$('.demand').hide(); $('.supply').fadeIn(); $('#user_type').val('2');"><?php echo e(trans('common.btn_supplier')); ?></a></li>
            </ul>

            <div id="contract">
                <h4 class="demand" style="<?php echo e(old('user_type')!=2 ? '' : 'display:none'); ?>"><?php echo e(trans('common.search_services')); ?></h4>
                <h4 class="supply" style="<?php echo e(old('user_type')==2 ? '' : 'display:none'); ?>"><?php echo e(trans('common.offers_services')); ?></h4>
<?php if($errors->any()): ?>
    <?php foreach($errors->all() as $error): ?>
        <p><?php echo e($error); ?></p>
    <?php endforeach; ?>
<?php endif; ?>            
                <form id="registration-form" method="post" action="<?php echo e(url('/register')); ?>">
                <fieldset>
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="user_type" id="user_type" value="<?php echo e(old('user_type')==2 ? '2' : '1'); ?>"/>

                    <p><?php echo e(trans('register.user_information')); ?>:</p>
                    
                    <label for="email">Email<span class="red">*</span>:</label>
<?php if($errors->has('email')): ?><strong><?php echo e($errors->first('email')); ?></strong><?php endif; ?>
                    <input type="email" name="email" id="email" class="email" required placeholder="Email*" value="<?php echo e(old('email')); ?>">

                    <label for="password"><?php echo e(trans('common.password')); ?><span class="red">*</span>:</label>
<?php if($errors->has('password')): ?><strong><?php echo e($errors->first('password')); ?></strong><?php endif; ?>
                    <input type="password" name="password" id="password" class="password" required placeholder="<?php echo e(trans('common.password')); ?>*">
                    
                    <label for="password_confirmation"><?php echo e(trans('common.password_confirmation')); ?><span class="red">*</span>:</label>
                    <input type="password" name="password_confirmation" id="password_confirmation" class="password" required placeholder="<?php echo e(trans('common.password_confirmation')); ?>*">
                    
                    <label for="username"><?php echo e(trans('common.username')); ?><span class="red">*</span>:</label>
<?php if($errors->has('username')): ?><strong><?php echo e($errors->first('username')); ?></strong><?php endif; ?>
                    <input type="text" name="username" id="username" class="username" required placeholder="<?php echo e(trans('common.username')); ?>*" value="<?php echo e(old('username')); ?>">
                    
                    <p><?php echo e(trans('register.additional_information')); ?>:</p>
                    
                    <label for="name"><?php echo e(trans('users.name')); ?><span class="red">*</span>:</label>
<?php if($errors->has('name')): ?><strong><?php echo e($errors->first('name')); ?></strong><?php endif; ?>
                    <input type="text" name="name" id="name" class="name" required placeholder="<?php echo e(trans('users.name')); ?>*" value="<?php echo e(old('name')); ?>">
                
                    <label for="phone"><?php echo e(trans('users.phone')); ?><span class="red">*</span>:</label>
<?php if($errors->has('phone')): ?><strong><?php echo e($errors->first('phone')); ?></strong><?php endif; ?>
                    <input type="tel" name="phone" id="phone" class="telephone" required placeholder="<?php echo e(trans('users.phone')); ?>*" value="<?php echo e(old('phone')); ?>">

                    <label for="cl_organization_type_id"><?php echo e(trans('users.org_type')); ?></label>
<?php if($errors->has('cl_organization_type_id')): ?><strong><?php echo e($errors->first('cl_organization_type_id')); ?></strong><?php endif; ?>
                    <select name="cl_organization_type_id" id="cl_organization_type_id">
                        <option value="" selected><?php echo e(trans('users.org_type')); ?></option>
<?php foreach($cl_organization_types as $organization_type): ?>
                        <option value="<?php echo e($organization_type->id); ?>" <?php echo e((old('cl_organization_type_id')==$organization_type->id) ? "selected":""); ?>><?php echo e($organization_type->getTranslation(\Session::get('language'))->organization_type); ?></option>
<?php endforeach; ?>
                    </select>
                    
                    <label for="org_name"><?php echo e(trans('users.org_name')); ?></label>
                    <input type="text" name="org_name" id="org_name" class="company" placeholder="<?php echo e(trans('users.org_name')); ?>" value="<?php echo e(old('org_name')); ?>">
                
                    <label for="reg_number"><?php echo e(trans('users.reg_number')); ?></label>
                    <input type="text" name="reg_number" id="reg_number" class="eik" placeholder="<?php echo e(trans('users.reg_number')); ?>" value="<?php echo e(old('reg_number')); ?>">
                
                    <label for="vat_number"><?php echo e(trans('users.vat_number')); ?></label>
                    <input type="text" name="vat_number" id="vat_number" class="dds" placeholder="<?php echo e(trans('users.vat_number')); ?>" value="<?php echo e(old('vat_number')); ?>">
                
                    <label for="address"><?php echo e(trans('users.address')); ?></label>
                    <input type="text" name="address" id="address" class="address" placeholder="<?php echo e(trans('users.address')); ?>" value="<?php echo e(old('address')); ?>">

                    <div class="supply" style="<?php echo e(old('user_type')==2 ? '' : 'display:none'); ?>">
                        <p><?php echo e(trans('users.regions_label')); ?></p>
                        <hr>
                        <p style="font-size: 26px;">
                            <a href="javascript:void(0)" onclick="$('.checkboxes-group :checkbox').prop('checked', true); $(this).blur()"><i class="fa fa-check-square"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
                            <a href="javascript:void(0)" onclick="$('.checkboxes-group :checkbox').prop('checked', false); $(this).blur()"><i class="fa fa-square"></i></a>
                        </p>
                        <div class="checkboxes-group">
<?php foreach($cl_regions as $region): ?>
                            <input type="checkbox" <?php echo e((old('regions.'.$region->id) == $region->id) ? "checked":""); ?> name="regions[<?php echo e($region->id); ?>]" id="regions[<?php echo e($region->id); ?>]" value="<?php echo e($region->id); ?>">
                            <label for="regions[<?php echo e($region->id); ?>]"><?php echo e($region->getTranslation(\Session::get('language'))->region); ?></label><br/>
<?php endforeach; ?>
                        </div>
                       
                        <p><?php echo e(trans('users.services_label')); ?><br/><em><?php echo e(trans('users.services_help_text')); ?></em></p>
                        <hr>
<?php foreach($cl_services as $service): ?>
                        <div class="checkbox">
                            <input type="checkbox" <?php echo e((old('services.'.$service->id) == $service->id) ? "checked":""); ?> name="services[<?php echo e($service->id); ?>]" id="supply-filed<?php echo e($service->id); ?>" value="<?php echo e($service->id); ?>" data-related-item="supply-budget<?php echo e($service->id); ?>">
                            <label for="supply-filed<?php echo e($service->id); ?>"><?php echo e($service->getTranslation(\Session::get('language'))->service); ?></label>
                        </div>

                        <div style="display: none;">
                            <label for="supply-budget<?php echo e($service->id); ?>"><?php echo e(trans('users.min_budget_placeholder')); ?>:</label>
                            <input type="number" min="0" name="budget[<?php echo e($service->id); ?>]" id="supply-budget<?php echo e($service->id); ?>" class="budget" placeholder="<?php echo e(trans('users.min_budget_placeholder')); ?>" value="<?php echo e(old('budget.'.$service->id)); ?>">
                        </div>
<?php endforeach; ?>
                        <p><?php echo e(trans('users.language_label')); ?></p>
<?php if($errors->has('cl_languages')): ?><strong><?php echo e($errors->first('cl_languages')); ?></strong><?php endif; ?>
                        <hr>
<?php foreach($cl_languages as $language): ?>
                        <div class="checkbox">
                            <input type="checkbox" name="cl_languages[<?php echo e($language->locale_code); ?>]" id="cl_language_<?php echo e($language->locale_code); ?>" value="<?php echo e($language->language); ?>" onchange="toggle_description('<?php echo e($language->locale_code); ?>')" <?php echo e((old('cl_languages.'.$language->locale_code) == $language->language) || $language->locale_code == 'bg' ? "checked":""); ?>>
                            <label for="cl_language_<?php echo e($language->locale_code); ?>"><?php echo e($language->language); ?></label>
                        </div>
<?php endforeach; ?>
                        <p><?php echo e(trans('users.description_label')); ?></p>
                        <label for="description_bg"><?php echo e(trans('users.description_bg')); ?><span class="red">*</span>:</label>
                        <textarea name="description[bg]" id="description_bg" placeholder="<?php echo e(trans('users.description_bg')); ?>*" onFocus="focusLink(true)" onBlur="focusLink(false)"><?php echo e(old('description.bg')); ?></textarea>
<?php foreach($cl_languages as $language): ?>
    <?php if($language->locale_code != 'bg'): ?>

                        <div id="description-wrapper_<?php echo e($language->locale_code); ?>" style="<?php echo e(old('cl_languages.'.$language->locale_code) ? "":"display: none"); ?>">
                            <label for="description_<?php echo e($language->locale_code); ?>"><?php echo e(trans('users.description_'.$language->locale_code)); ?><span class="red">*</span>:</label>
                            <textarea name="description[<?php echo e($language->locale_code); ?>]" id="description_<?php echo e($language->locale_code); ?>" placeholder="<?php echo e(trans('users.description_'.$language->locale_code)); ?>*" onFocus="focusLink(true)" onBlur="focusLink(false)"><?php echo e(old('description.'.$language->locale_code)); ?></textarea>
                        </div>
    <?php endif; ?>
<?php endforeach; ?>

                        <script type="text/javascript">
                            function toggle_description(id){
                                if (id == 'bg'){ $('#cl_language_bg').prop('checked', true); }
                                if ($('#cl_language_'+id).is(':checked')){ $('#description-wrapper_'+id).slideDown(); }
                                else{ $('#description-wrapper_'+id).slideUp(); }
                            }
                        </script>

                    </div>

                    <div class="checkbox">
                        <input type="checkbox" name="agreement" id="agreement" required <?php echo e((old('agreement') == "Agreed with Ptivacy Policy") ? "checked":""); ?> value="Agreed with Ptivacy Policy">
                        <label for="agreement"><?php echo e(trans('common.have_read')); ?> <a href="#" target="_blank"><?php echo e(trans('common.terms_and_conditions')); ?></a><span class="red">*</span></label>
                    </div>
                
                    <input type="submit" value="<?php echo e(trans('common.btn_continue')); ?>">
                    
                </fieldset>
                </form> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>