<?php $__env->startSection('content'); ?>
<!--Header-->

<div class="header small">
    <div class="overlay">
        <h2><?php echo e(trans('articles.add_article_title')); ?></h2>
    </div>
</div>

<!--Header END-->

<div class="content"><!--Content Starts-->

    <section class="profile">
        <div class="container">
            <div class="boxes layout-left">
                <div class="box">
                    <h4><?php echo e(trans('articles.add_article_subtitle')); ?></h4>

                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <?php foreach($errors->all() as $error): ?>
                        <p><?php echo e($error); ?></p>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>

                    <form action="<?php echo e(url('/add-article')); ?>" method="post" enctype="multipart/form-data">
                        <fieldset>
                            <?php echo e(csrf_field()); ?>


                            <label for="demand-objectype"><?php echo e(trans('articles.article_type')); ?></label>
                            <select name="cl_article_type_id" id="demand-objectype" required>
                                <option value=""><?php echo e(trans('articles.article_type_default')); ?></option>
                                <?php foreach($cl_article_types as $article_type): ?>
                                <?php
                                    $selected = '';
                                    if($article_type->id == old('cl_article_type_id'))
                                    {
                                        $selected = 'selected';
                                    }
                                ?>
                                <option value="<?php echo e($article_type->id); ?>" <?php echo e($selected); ?>><?php echo e($article_type->getTranslation(\Session::get('language'))->article_type); ?></option>
                                <?php endforeach; ?>
                            </select>

                            <label for="topic"><?php echo e(trans('articles.topic')); ?><span class="red">*</span>:</label>
                            <input type="text" name="topic" id="topic" required placeholder="<?php echo e(trans('articles.topic')); ?>*" value="<?php echo e(old('topic')); ?>">

                            <label for="content"><?php echo e(trans('articles.content')); ?><span class="red">*</span>:</label>
                            <textarea name="content" id="content" placeholder="<?php echo e(trans('articles.content')); ?>*" onFocus="focusLink(true)" onBlur="focusLink(false)" required><?php echo e(old('content')); ?></textarea>

                            <label for="picture"><?php echo e(trans('articles.picture')); ?></label>
                            <input type="file" name="picture" id="picture" placeholder="<?php echo e(trans('articles.picture')); ?>">

                            <div class="checkbox">
                                <?php
                                if( ! empty(old('is_paid')))
                                {
                                    $checked = 'checked';
                                }else{
                                    $checked = '';
                                }
                                ?>
                                <input type="checkbox" name="is_paid" id="is_paid" value="1" <?php echo e($checked); ?>>
                                <label for="is_paid"><?php echo e(trans('articles.is_paid')); ?></label>
                            </div>

                            <input type="submit" value="<?php echo e(trans('common.btn_save')); ?>">
                        </fieldset>
                    </form>

                </div>

<script>
    CKEDITOR.replace( 'content' );
</script>

                <?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>