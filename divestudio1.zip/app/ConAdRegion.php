<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ConAdRegion extends Model
{
    protected $fillable = ['cm_ad_id','cl_region_id'];
}
