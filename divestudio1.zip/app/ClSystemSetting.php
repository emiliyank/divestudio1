<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClSystemSetting extends Model
{ 
    protected $fillable = ['rating_period'];
}

