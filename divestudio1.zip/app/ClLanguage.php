<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClLanguage extends Model
{
    protected $fillable = ['language','language_code'];
}

