<?php

return [
    'registration' => 'registration',
    'role' => 'role',
    'choice_role' => 'Please select your role. (Read',
    'more_for_roles' => 'more for the roles here',
    'user_information' => 'User Information',
    'additional_information' => 'Additional Information',
    'forgotten_password' => 'Forgotten Password',
    'send_password_reset_link' => 'Send Password Reset Link',
];
