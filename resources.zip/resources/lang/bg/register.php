<?php

return [
    'registration' => 'Регистрация',
    'role' => 'роля',
    'choice_role' => 'Моля изберете вашата роля. (Прочетете',
    'more_for_roles' => 'повече за ролите тук',
    'user_information' => 'Информация за потребителя',
    'additional_information' => 'Допълнителна информация',
    'forgotten_password' => 'Забравена парола',
    'send_password_reset_link' => 'Изпрати линк за нова парола',
    'reset_pass_btn' => 'Обнови паролата',
];
