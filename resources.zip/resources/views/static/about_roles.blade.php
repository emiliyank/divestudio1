@extends('layouts.dashboard')

@section('content')
<!--Header-->

<div class="header small">
    <div class="overlay">
        <h2>{{trans('static.about_roles_title')}}</h2>
    </div>
</div>

<!--Header END-->

@endsection




